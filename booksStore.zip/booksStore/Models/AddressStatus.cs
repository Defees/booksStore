﻿using System;
using System.Collections.Generic;

namespace booksStore.Models;

public partial class AddressStatus
{
    public int StatusId { get; set; }

    public string? AddressStatus1 { get; set; }
}
